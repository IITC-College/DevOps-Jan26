#!/bin/bash
# Example Script with Execute Permission
# This script already has execute permission set

echo "This script has execute permission"
echo "You can run it directly with ./example.sh"
echo "Notice the 'x' in the permissions: -rwxr-xr-x"
