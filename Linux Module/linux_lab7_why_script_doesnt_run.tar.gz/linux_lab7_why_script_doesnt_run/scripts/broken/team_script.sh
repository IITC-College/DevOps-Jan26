#!/bin/bash
# Team Script
# This script should be executable by team members (group)

echo "Team collaboration script"
echo "This script can be run by team members"
echo "Use chmod g+x to add execute permission for the group"
