# Workspace Directory

This is a workspace directory for practice.

## Navigation Practice

You've successfully navigated to this directory!

Try:
- `pwd` to see where you are
- `ls -a` to see all files
- `cd ..` to go back
