# Mixed Issues Scenario

This scenario contains multiple broken things that need to be fixed.

Apply the 4-step methodology to each problem separately.

Good luck!
