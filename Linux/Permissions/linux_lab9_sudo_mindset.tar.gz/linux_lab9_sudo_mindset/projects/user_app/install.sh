#!/bin/bash
# User Application Installation Script

echo "Installing user application..."
echo "This script should be owned by the user, not root."

# Installation steps would go here
echo "Installation complete!"

# Note: This script should NOT require sudo to run (for a user app)
# If it's owned by root, that's a design problem - fix ownership!
