# Personal Project

This is a personal project directory.

## Files

- my_script.sh - Personal executable script
- my_notes.txt - Private notes
- README.md - This file (public documentation)

The README is readable by everyone (rw-r--r--), but the other files
are private to the owner.
