#!/bin/bash
# Sample executable script - used in Lab 1 Level 2 Clue 1 for permission comparison.
echo "This is a sample script with execute permission."
