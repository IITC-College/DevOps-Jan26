#!/bin/bash
# BROKEN - find and fix: spaces in variable assignment

APP_NAME = "myapp"

echo "Building $APP_NAME..."
echo "Build step complete."
